# TerrainScope — Quadtree Terrain Classification

A complete, responsive educational website for the topic:

**Region Splitting and Merging for Terrain Classification — Quadtree Segmentation**

## Run in VS Code

1. Extract the ZIP.
2. Open the `terrain_quadtree_website` folder in VS Code.
3. Open `index.html` in a browser.

Recommended: install the **Live Server** extension in VS Code and choose **Open with Live Server**.

No backend, npm, build tools, or external JavaScript libraries are required.

## Folder structure

```text
terrain_quadtree_website/
├── index.html
├── README.md
├── css/
│   └── style.css
└── js/
    └── script.js
```

## Included

- Modern academic/technical visual design
- Responsive layout for desktop, tablet and mobile
- Quadtree segmentation explanation
- Region splitting and homogeneity test
- Region merging explanation
- Interactive terrain simulator
- Adjustable homogeneity threshold
- Adjustable maximum quadtree depth
- Three terrain modes
- Live region count
- Animated segmentation
- Algorithm workflow
- Quadtree data-structure diagram
- Applications and comparison section
- No backend required
