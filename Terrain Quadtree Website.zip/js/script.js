// TerrainScope — interactive quadtree segmentation demo
const hero = document.getElementById("heroCanvas");
const hctx = hero.getContext("2d");
const canvas = document.getElementById("quadtreeCanvas");
const ctx = canvas.getContext("2d");

let terrainType = "mixed";
let threshold = 34;
let maxDepth = 5;
let cells = [];
let running = false;

// Deterministic smooth terrain functions make the demo work offline.
function terrainValue(x, y, type = terrainType) {
  const hills = Math.sin(x * 0.055) * 0.22 + Math.cos(y * 0.07) * 0.16 +
    Math.sin((x + y) * 0.028) * 0.12;
  const ridge = Math.exp(-Math.pow((x - y * 0.85 - 90) / 85, 2)) * 0.3;
  const forest = Math.sin(x * 0.22) * Math.sin(y * 0.18) * 0.12;
  if (type === "mountain") return .45 + hills + ridge + Math.sin(y*.018)*.15;
  if (type === "plains") return .48 + hills*.35 + Math.sin(x*.012)*.04;
  return .48 + hills + ridge + forest;
}
function clamp(v,a,b){return Math.max(a,Math.min(b,v));}

function drawTerrain(c, w, h, type = terrainType, detail = true) {
  const img = c.createImageData(w,h);
  for(let y=0;y<h;y++){
    for(let x=0;x<w;x++){
      let v=clamp(terrainValue(x,y,type),0,1);
      let r,g,b;
      if(v<.28){r=91;g=104;b=71}
      else if(v<.43){r=137;g=143;b=91}
      else if(v<.58){r=185;g=181;b=116}
      else if(v<.73){r=139;g=126;b=87}
      else{r=92;g=91;b=76}
      const i=(y*w+x)*4;
      const grain=detail ? (Math.sin(x*1.9+y*.7)*3) : 0;
      img.data[i]=clamp(r+grain,0,255); img.data[i+1]=clamp(g+grain,0,255); img.data[i+2]=clamp(b+grain,0,255); img.data[i+3]=255;
    }
  }
  c.putImageData(img,0,0);
}

function renderHero(){
  drawTerrain(hctx,hero.width,hero.height,"mixed",false);
  hctx.save(); hctx.strokeStyle="rgba(255,255,255,.18)"; hctx.lineWidth=1;
  for(let x=0;x<hero.width;x+=90){hctx.beginPath();hctx.moveTo(x,0);hctx.lineTo(x,hero.height);hctx.stroke()}
  for(let y=0;y<hero.height;y+=90){hctx.beginPath();hctx.moveTo(0,y);hctx.lineTo(hero.width,y);hctx.stroke()}
  hctx.restore();
}
renderHero();

function regionStats(x,y,size){
  let sum=0,sum2=0,count=0, step=Math.max(2,Math.floor(size/12));
  for(let yy=y+step/2; yy<y+size; yy+=step){
    for(let xx=x+step/2; xx<x+size; xx+=step){
      const v=terrainValue(xx,yy);
      sum+=v; sum2+=v*v; count++;
    }
  }
  const mean=sum/count, variance=Math.max(0,sum2/count-mean*mean);
  return {mean, variance};
}

function shouldSplit(stat, depth){
  const normalized = stat.variance*1000;
  return depth < maxDepth && normalized > threshold;
}

function buildTree(){
  cells=[];
  function split(x,y,size,depth){
    const stat=regionStats(x,y,size);
    if(shouldSplit(stat,depth)){
      const half=size/2;
      split(x,y,half,depth+1); split(x+half,y,half,depth+1);
      split(x,y+half,half,depth+1); split(x+half,y+half,half,depth+1);
    }else cells.push({x,y,size,depth,mean:stat.mean});
  }
  split(0,0,canvas.width,0);
  document.getElementById("regionCount").textContent=cells.length;
  document.getElementById("metricDepth").textContent=maxDepth;
}

function drawDemo(progress=1){
  ctx.clearRect(0,0,canvas.width,canvas.height);
  drawTerrain(ctx,canvas.width,canvas.height,terrainType,true);
  ctx.save();
  ctx.lineWidth=1;
  cells.forEach((cell,i)=>{
    if(i/cells.length>progress)return;
    ctx.strokeStyle=cell.depth>=maxDepth-1 ? "rgba(22,43,34,.65)" : "rgba(25,47,37,.42)";
    ctx.strokeRect(cell.x+.5,cell.y+.5,cell.size-1,cell.size-1);
    if(cell.size>=90 && cell.mean<.4){
      ctx.fillStyle="rgba(190,220,76,.10)";
      ctx.fillRect(cell.x,cell.y,cell.size,cell.size);
    }
  });
  ctx.restore();
}

function animateSegmentation(){
  if(running)return;
  running=true;
  document.getElementById("status").textContent="SPLITTING…";
  let p=0;
  const start=performance.now();
  function frame(now){
    p=Math.min(1,(now-start)/850);
    drawDemo(p);
    if(p<1)requestAnimationFrame(frame);
    else {running=false;document.getElementById("status").textContent="COMPLETE";}
  }
  requestAnimationFrame(frame);
}

function reset(){
  threshold=34; maxDepth=5;
  document.getElementById("threshold").value=threshold;
  document.getElementById("depth").value=maxDepth;
  document.getElementById("thresholdValue").textContent=threshold;
  document.getElementById("depthValue").textContent=maxDepth;
  document.getElementById("status").textContent="READY";
  buildTree(); drawDemo();
}

document.getElementById("threshold").addEventListener("input",e=>{
  threshold=+e.target.value;
  document.getElementById("thresholdValue").textContent=threshold;
  buildTree();drawDemo();
});
document.getElementById("depth").addEventListener("input",e=>{
  maxDepth=+e.target.value;
  document.getElementById("depthValue").textContent=maxDepth;
  buildTree();drawDemo();
});
document.getElementById("animateBtn").addEventListener("click",animateSegmentation);
document.getElementById("resetBtn").addEventListener("click",reset);

document.querySelectorAll(".terrain-option").forEach(btn=>{
  btn.addEventListener("click",()=>{
    document.querySelectorAll(".terrain-option").forEach(b=>b.classList.remove("active"));
    btn.classList.add("active");
    terrainType=btn.dataset.terrain;
    document.getElementById("canvasMode").textContent=terrainType.toUpperCase()+" TERRAIN";
    buildTree();drawDemo();
  });
});

buildTree();drawDemo();

const observer=new IntersectionObserver(entries=>{
  entries.forEach(entry=>{if(entry.isIntersecting)entry.target.classList.add("visible")});
},{threshold:.12});
document.querySelectorAll(".reveal").forEach(el=>observer.observe(el));

window.addEventListener("resize",()=>{ /* CSS handles layout; canvas uses fixed logical resolution */ });
